<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    //
    public function products()
    {
        $products = Product::all();
        $first = Product::first();
        foreach ($products as $key => $value) {
            $sss=$value->category;
        }
        return response()->json([
            'products' => $products,
            // 'products_id' => $sss,
            'code' => 200
        ]);
    }
    public function categories()
    {
        $categories = Category::all();
        return response()->json([
            'categories' => $categories,
            'code' => 200
        ]);
    }

    public function filter_products(Request $request)
    {
        if ($request->filter_type == "no-stocks") {
            $products = Product::where('quantity', 0)->get();
            $first = Product::first();
            foreach ($products as $key => $value) {
                $sss=$value->category;
            }
            return response()->json([
                'products' => $products,
                'code' => 200,
                'ass' => $request->filter_type
            ]);
        } elseif ($request->filter_type == "all") {
            $products = Product::all();
            $first = Product::first();
            foreach ($products as $key => $value) {
                $sss=$value->category;
            }
        return response()->json([
                'products' => $products,
                'code' => 200
            ]);
        } else{
            $products = Product::where('quantity', '!=' , 0)->get();
            $first = Product::first();
            foreach ($products as $key => $value) {
                $sss=$value->category;
            }
            return response()->json([
                'products' => $products,
                'code' => 200
            ]);
        }
    }

    public function save_product(Request $request)
    {
        $product = new Product();
        
         $product->name =  $request->name;
         $product->description =  $request->description;
         $product->price =  $request->price;
         $product->quantity =  $request->quantity;
         $product->category_id =  $request->category_id;
         $product->save();
        return response()->json([
            'message' => 'Product inserted successfully',
            'code' => 200
        ]);
    }
    public function delete_product($id)
    {
        $product = Product::find($id);
        
        if ($product) {
            $product->delete();
            return response()->json([
                'message' => 'Product deleted successfully',
                'code' => 200
            ]);
        } else {
            return response()->json([
                'message' => 'Product with the id of ' . $id . " do not exist.",
            ]);
        }
    }
    public function edit_product($id)
    {
        $product = Product::find($id);

        return response()->json($product);
        
    }
    public function update_product(Request $request, $id)
    {
        $product = Product::where('id', $id)->first();

         $product->name =  $request->name;
         $product->description =  $request->description;
         $product->price =  $request->price;
         $product->quantity =  $request->quantity;
         $product->category_id =  $request->category_id;
         $product->save();
        return response()->json([
            'message' => 'Product updated successfully',
            'code' => 200
        ]);
    }
}
